# Bootstrap 4 Start Template
Kick Start your Bootstrap 4 Project with this lightweight template, it only loads the require bootstrap files plus a stylesheet and a javascript file for your custom code.

## Instructions

- Download this project
- Decompress
- Change directory name
- Build Something great

# Template Bootstrap 4
Inicia tu proyecto con este template ligero, solo viene con los archivos necesarios, así como una hoja de estilos y una archivo javascript para tu código.

## Instrucciones

- Descarga este proyecto
- Descomprime
- Cambia el nombre del proyecto
- Crea algo increible!
